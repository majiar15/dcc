@extends('layouts.modulo')

@section('content')
Pagina Home :v no se que poner aun 
@endsection
