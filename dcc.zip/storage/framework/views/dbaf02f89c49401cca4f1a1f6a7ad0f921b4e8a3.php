<?php $__env->startSection('content'); ?>


<?php if(is_string($horas)): ?>
<h3 class="massage_month" ><?php echo e($horas); ?></h3>
<?php else: ?>
<h3 class="massage_month" >Horas Registradas en el mes de <?php echo e($name_mes); ?> </h3>
<table border='1' id="hours">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Horas Trabajadas</th>
        </tr>
    </thead>
<?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
           <td>
            <?php echo e($hora['name']." ".$hora['last_name']); ?>

           </td>
   
           <td>
           <?php echo e($hora['hours']); ?>

           </td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
</table>

<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modulo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dcc\dcc\resources\views/user/verHoras.blade.php ENDPATH**/ ?>