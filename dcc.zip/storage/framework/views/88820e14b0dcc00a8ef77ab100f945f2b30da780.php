<?php $__env->startSection('content'); ?>
Pagina Home :v no se que poner aun 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modulo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dcc\dcc\resources\views/home.blade.php ENDPATH**/ ?>