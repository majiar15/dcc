<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\hora;
use Faker\Generator as Faker;

$factory->define(hora::class, function (Faker $faker) {
    return [
        //
    ];
});
