<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\users_horas;
use Faker\Generator as Faker;

$factory->define(users_horas::class, function (Faker $faker) {
    return [
        //
    ];
});
